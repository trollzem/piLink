#!/bin/bash
set -e

if ! mountpoint -q /sys/kernel/config; then
    mount -t configfs none /sys/kernel/config
fi
modprobe libcomposite

GADGET_DIR=/sys/kernel/config/usb_gadget/pidisplay
if ! [ -d "$GADGET_DIR" ] || ! [ -s "$GADGET_DIR/UDC" ]; then
    rm -rf "$GADGET_DIR" 2>/dev/null || true
    mkdir -p "$GADGET_DIR"
    cd "$GADGET_DIR"

    echo 0x1d6b > idVendor
    echo 0x0104 > idProduct
    echo 0x0100 > bcdDevice
    echo 0x0200 > bcdUSB

    mkdir -p strings/0x409
    echo "0000000000000001" > strings/0x409/serialnumber
    echo "Raspberry Pi" > strings/0x409/manufacturer
    echo "Pi Display Gadget" > strings/0x409/product

    mkdir -p configs/c.1/strings/0x409
    echo "CDC ECM" > configs/c.1/strings/0x409/configuration
    echo 250 > configs/c.1/MaxPower

    mkdir -p functions/ecm.usb0
    echo "02:00:00:00:00:01" > functions/ecm.usb0/host_addr
    echo "02:00:00:00:00:02" > functions/ecm.usb0/dev_addr

    ln -s functions/ecm.usb0 configs/c.1/

    UDC=$(ls /sys/class/udc | head -n1)
    [ -n "$UDC" ] && echo "$UDC" > UDC
fi

for i in 1 2 3 4 5 6 7 8 9 10; do
    [ -e /sys/class/net/usb0 ] && break
    sleep 1
done

if [ -e /sys/class/net/usb0 ]; then
    ip link set usb0 up
    ip addr flush dev usb0 2>/dev/null || true
    ip addr add 192.168.69.2/24 dev usb0
fi

exit 0
